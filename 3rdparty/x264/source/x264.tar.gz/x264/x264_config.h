#define X264_GPL           1
#define X264_INTERLACED    1
#define X264_BIT_DEPTH     0
#define X264_CHROMA_FORMAT 0
#define X264_REV 3094
#define X264_REV_DIFF 0
#define X264_VERSION " r3094 bfc87b7"
#define X264_POINTVER "0.164.3094 bfc87b7"
